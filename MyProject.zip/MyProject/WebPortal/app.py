#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 13 15:14:31 2019

@author: tyesp
"""
from datetime import datetime
from flask import Flask,session, request, flash, url_for, redirect, render_template, abort ,g
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_login import login_user , logout_user , current_user , login_required
from werkzeug.security import generate_password_hash, check_password_hash
import os, sys

app = Flask(__name__, static_url_path="/static", static_folder="static")
app.config.from_pyfile('webportal.cfg')
db = SQLAlchemy(app)
db.create_all()

login_manager = LoginManager()
login_manager.init_app(app)

login_manager.login_view = 'login'

@app.route('/')
@app.route('/login')
def login():
    if "env_user" in session:
        return render_template('dashboard.html')
    return render_template('index.html')



if __name__ == '__main__':
    app.run()